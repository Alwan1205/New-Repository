﻿static var gscore : int = 0;

function OnGUI(){





GUI.Label (Rect (10, 10,1000,100), ("You Lose. Your Score: " +gscore ));


}