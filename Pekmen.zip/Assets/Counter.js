﻿function OnTriggerEnter (info: Collider){
 Destroy (gameObject);
 ScoreCount.gscore+=1;
 ScoreLvl1.gscore+=1;

}