﻿
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class GameOver: MonoBehaviour {




	public void button_click(){
		SceneManager.LoadScene("menu");
		// Use this for initialization
	}

	public void Exit(){
		Application.Quit ();
	}



}


