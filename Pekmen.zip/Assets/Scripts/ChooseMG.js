﻿

function OnGUI(){

GUI.Label (Rect(250,10,100,1000), ("Choose Mini Game: "));

}