﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Instant : MonoBehaviour {

	// Use this for initialization

}
