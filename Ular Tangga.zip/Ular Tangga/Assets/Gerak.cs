﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine.UI;
using UnityEngine;


public class Gerak : MonoBehaviour {

    // Use this for initialization
    private int giliran = 1;
    private int dadu;
    public Text daduText;
    public Text menangText;
    public Text giliranText;
    public Text statusText;
    public GameObject player2;


	void Start () {
        dadu = 0;
        SetDaduText();
    }
	
	// Update is called once per frame
	void Update () {
        //giliran Player1
        if (giliran == 1)
        {
            GiliranPlayer1Text();
            if (Input.GetKeyDown(KeyCode.Space))
            {
                int random;
                random = Random.Range(0, 5);
                dadu = random + 1;

                //mengosongkan text
                statusText.text = "";
                menangText.text = "";

                SetDaduText();
                Player1Gerak();
                CekUlarTangga1();
                giliran = 2;
            }            
        }

        else
        {
            GiliranPlayer2Text();
            if (Input.GetKeyDown(KeyCode.Space))
            {
                int random;
                random = Random.Range(0, 5);
                dadu = random + 1;

                //mengosongkan text
                statusText.text = "";
                menangText.text = "";

                SetDaduText();
                Player2Gerak();
                CekUlarTangga2();
                giliran = 1;
            }            
        }
    }

    void SetDaduText()
    {
        daduText.text = "Roll= " + dadu.ToString();
    }

    void GiliranPlayer1Text()
    {
        giliranText.text = "Giliran Player Merah!";
    }

    void GiliranPlayer2Text()
    {
        giliranText.text = "Giliran Player Biru!";
    }

    void Player1MenangText()
    {
        menangText.text = "Player Merah Menang!";
    }

    void Player2MenangText()
    {
        menangText.text = "Player Biru Menang!";
    }

    void Player1Gerak()
    {
        for (int langkah = dadu; langkah > 0; langkah--)
        {
            //kanan
            if(transform.position.x > -12 &&
                (transform.position.z == 10 || transform.position.z == -2 || transform.position.z == -14))
            {
                transform.position = new Vector3(transform.position.x - 5, transform.position.y, transform.position.z);
            }

            //kiri
            else if(transform.position.x < 13 &&
                (transform.position.z == 4 || transform.position.z == -8))
            {
                transform.position = new Vector3(transform.position.x + 5, transform.position.y, transform.position.z);
            }

            //atas
            else
            {
                transform.position = new Vector3(transform.position.x, transform.position.y, transform.position.z - 6);
            }

            //mencapai 30
            if(transform.position.x == -12 && transform.position.z == -14)
            {
                //lebih dari 30
                if (langkah > 1) //karena langkah belum dikurangi fungsi for
                {
                    do
                    {
                        transform.position = new Vector3(transform.position.x + 5, transform.position.y, transform.position.z);
                        langkah--;
                    } while (langkah > 1); //langkah = 1 artinya langkah = 0 setelah dikurangi fungsi for
                }

                //pas di 30
                else
                {
                    Player1MenangText();
                    transform.position = new Vector3(13, 2, 10);
                    player2.transform.position = new Vector3(12, 2, 13);
                }
            }

            //tambah fungsi wait
        }
    }

    void Player2Gerak()
    {
        for (int langkah = dadu; langkah > 0; langkah--)
        {
            //kanan
            if (player2.transform.position.x > -13 &&
                (player2.transform.position.z == 13 || player2.transform.position.z == 1 || player2.transform.position.z == -11))
            {
                player2.transform.position = new Vector3(player2.transform.position.x - 5, player2.transform.position.y, player2.transform.position.z);
            }

            //kiri
            else if (player2.transform.position.x < 12 &&
                (player2.transform.position.z == 7 || player2.transform.position.z == -5))
            {
                player2.transform.position = new Vector3(player2.transform.position.x + 5, player2.transform.position.y, player2.transform.position.z);
            }

            //atas
            else
            {
                player2.transform.position = new Vector3(player2.transform.position.x, player2.transform.position.y, player2.transform.position.z - 6);
            }

            //mencapai 30
            if (player2.transform.position.x == -13 && player2.transform.position.z == -11)
            {
                //lebih dari 30
                if (langkah > 1) //karena langkah belum dikurangi fungsi for
                {
                    do
                    {
                        player2.transform.position = new Vector3(player2.transform.position.x + 5, player2.transform.position.y, player2.transform.position.z);
                        langkah--;
                    } while (langkah > 1); //langkah = 1 artinya langkah = 0 setelah dikurangi fungsi for
                }

                //pas di 30
                else
                {
                    Player2MenangText();
                    transform.position = new Vector3(13, 2, 10);
                    player2.transform.position = new Vector3(12, 2, 13);
                }
            }

            //tambah fungsi wait
        }
    }

    void CekUlarTangga1()
    {
        //tangga
        if(transform.position.x == 3 && transform.position.z == 10)
        {
            transform.position = new Vector3(transform.position.x, transform.position.y, transform.position.z -18);
            statusText.text = "Kena tangga! Naik dari 3 ke 22";
        }

        else if (transform.position.x == -7 && transform.position.z == 10)
        {
            transform.position = new Vector3(transform.position.x, transform.position.y, transform.position.z - 6);
            statusText.text = "Kena tangga! Naik dari 5 ke 8";
        }

        else if (transform.position.x == 8 && transform.position.z == 4)
        {
            transform.position = new Vector3(transform.position.x, transform.position.y, transform.position.z - 18);
            statusText.text = "Kena tangga! Naik dari 11 ke 26";
        }

        else if (transform.position.x == -7 && transform.position.z == -8)
        {
            transform.position = new Vector3(transform.position.x, transform.position.y, transform.position.z - 6);
            statusText.text = "Kena tangga! Naik dari 20 ke 29";
        }

        //ular
        else if (transform.position.x == -7 && transform.position.z == -2)
        {
            transform.position = new Vector3(transform.position.x + 5, transform.position.y, transform.position.z + 12);
            statusText.text = "Kena ular! Turun dari 17 ke 4";
        }

        else if (transform.position.x == -12 && transform.position.z == -8)
        {
            transform.position = new Vector3(transform.position.x, transform.position.y, transform.position.z + 12);
            statusText.text = "Kena ular! Turun dari 19 ke 7";
        }

        else if (transform.position.x == -2 && transform.position.z == -8)
        {
            transform.position = new Vector3(transform.position.x, transform.position.y, transform.position.z + 12);
            statusText.text = "Kena ular! Turun dari 21 ke 9";
        }

        else if (transform.position.x == 3 && transform.position.z == -14)
        {
            transform.position = new Vector3(transform.position.x + 10, transform.position.y, transform.position.z + 24);
            statusText.text = "Kena ular! Turun dari 27 ke 1";
        }
    }

    void CekUlarTangga2()
    {
        //tangga
        if (player2.transform.position.x == 2 && player2.transform.position.z == 13)
        {
            player2.transform.position = new Vector3(player2.transform.position.x, player2.transform.position.y, player2.transform.position.z - 18);
            statusText.text = "Kena tangga! Naik dari 3 ke 22";
        }

        else if (player2.transform.position.x == -8 && player2.transform.position.z == 13)
        {
            transform.position = new Vector3(player2.transform.position.x, player2.transform.position.y, player2.transform.position.z - 6);
            statusText.text = "Kena tangga! Naik dari 5 ke 8";
        }

        else if (player2.transform.position.x == 7 && player2.transform.position.z == 7)
        {
            player2.transform.position = new Vector3(player2.transform.position.x, player2.transform.position.y, player2.transform.position.z - 18);
            statusText.text = "Kena tangga! Naik dari 11 ke 26";
        }

        else if (player2.transform.position.x == -8 && player2.transform.position.z == -5)
        {
            player2.transform.position = new Vector3(player2.transform.position.x, player2.transform.position.y, player2.transform.position.z - 6);
            statusText.text = "Kena tangga! Naik dari 20 ke 29";
        }

        //ular
        else if (player2.transform.position.x == -8 && player2.transform.position.z == 1)
        {
            player2.transform.position = new Vector3(player2.transform.position.x + 5, player2.transform.position.y, player2.transform.position.z + 12);
            statusText.text = "Kena ular! Turun dari 17 ke 4";
        }

        else if (player2.transform.position.x == -13 && player2.transform.position.z == -5)
        {
            player2.transform.position = new Vector3(player2.transform.position.x, player2.transform.position.y, player2.transform.position.z + 12);
            statusText.text = "Kena ular! Turun dari 19 ke 7";
        }

        else if (player2.transform.position.x == -3 && player2.transform.position.z == -5)
        {
            player2.transform.position = new Vector3(player2.transform.position.x, player2.transform.position.y, player2.transform.position.z + 12);
            statusText.text = "Kena ular! Turun dari 21 ke 9";
        }

        else if (player2.transform.position.x == 2 && player2.transform.position.z == -11)
        {
            player2.transform.position = new Vector3(player2.transform.position.x + 10, player2.transform.position.y, player2.transform.position.z + 24);
            statusText.text = "Kena ular! Turun dari 27 ke 1";
        }
    }
}
